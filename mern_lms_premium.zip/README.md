# MERN LMS Premium

Full stack LMS with React, Node, MongoDB.

## Run
Backend: npm install && node server.js
Frontend: npm install && npm start